<script>
    import About from './About.svelte';
</script>

<About />